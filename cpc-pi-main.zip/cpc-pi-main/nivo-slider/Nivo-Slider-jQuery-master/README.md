**Maintainer's Wanted!** - Ineterested in contributing regularly to Nivo Slider development? [Get in touch](https://themeisle.com/contact/)

# Nivo Slider

The Nivo Slider is world renowned as the most beautiful and easy to use image slider on the market. There is literally no better way to make your website look totally stunning.

WordPress Plugin:  https://themeisle.com/nivo-slider/ for more info.

Docs: http://docs.themeisle.com/article/485-getting-started-with-the-nivo-slider-jquery-plugin

If you are looking out for WordPress themes which nicely integrate Nivo Slider, check-out : https://themeisle.com/wordpress-themes/ or if you are looking for a web host where you can have your website hosted, see [this guide](https://www.codeinwp.com/blog/best-wordpress-hosting/), I am sure that it will help.

## Other Projects

Check-out other stuff that we are working on : 

* [Optionistics](https://optionistics.com)
* [Codeinwp](https://codeinwp.com/blog/)
* [Revive.social](https://revive.social)
* [FinMasters](https://finmasters.com)
