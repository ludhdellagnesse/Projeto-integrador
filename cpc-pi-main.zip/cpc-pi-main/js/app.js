
// pop-up
$(document).ready(function() {
    $('.pop-up',).magnificPopup({ delegate: 'a',type:'image',
    
  });
  });



  $(document).ready(function() {
    $('.link-mapa').magnificPopup({type:'iframe'});
  })
  // 

  //banner
  $('#lista-banner').nivoSlider({
    pauseOnHover:true,
    
  }

    
  )